require('dotenv').config();
const express = require('express');
const mysql = require('mysql');

const app = express();
const port = 3000;

// 1) Connessione MySQL
const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME
});

db.connect((err) => {
  if (err) {
    console.error('Errore di connessione al DB:', err);
    return;
  }
  console.log('Connesso al database MySQL!');
});

// 2) Middleware per leggere body JSON
app.use(express.json());

// 3) Rotta di test
app.get('/', (req, res) => {
  res.send('Benvenuto in Fishing Spot Finder!');
});

// 4) GET /spots: Legge tutti gli spot
app.get('/spots', (req, res) => {
  const sql = 'SELECT * FROM spots';
  db.query(sql, (err, results) => {
    if (err) {
      console.error('Errore nel recupero degli spot:', err);
      return res.status(500).json({ error: 'Errore nel recupero degli spot' });
    }
    res.json(results);
  });
});

// 5) POST /spots: Inserisce un nuovo spot
app.post('/spots', (req, res) => {
  const { name, lat, lng, description } = req.body;
  if (!name) {
    return res.status(400).json({ error: 'Il campo "name" è obbligatorio' });
  }

  const sql = 'INSERT INTO spots (name, lat, lng, description) VALUES (?, ?, ?, ?)';
  db.query(sql, [name, lat, lng, description], (err, result) => {
    if (err) {
      console.error('Errore durante l\'inserimento dello spot:', err);
      return res.status(500).json({ error: 'Errore durante l\'inserimento dello spot' });
    }
    res.json({
      message: 'Spot creato con successo',
      spotId: result.insertId
    });
  });
});

// 6) GET /spots/:id: Legge uno spot specifico
app.get('/spots/:id', (req, res) => {
  const spotId = req.params.id;
  const sql = 'SELECT * FROM spots WHERE id = ?';
  db.query(sql, [spotId], (err, results) => {
    if (err) {
      console.error('Errore nel recupero dello spot:', err);
      return res.status(500).json({ error: 'Errore nel recupero dello spot' });
    }
    if (results.length === 0) {
      return res.status(404).json({ error: 'Spot non trovato' });
    }
    res.json(results[0]);
  });
});

// 7) PUT /spots/:id: Aggiorna uno spot
app.put('/spots/:id', (req, res) => {
  const spotId = req.params.id;
  const { name, lat, lng, description } = req.body;

  if (!name) {
    return res.status(400).json({ error: 'Il campo "name" è obbligatorio' });
  }

  const sql = 'UPDATE spots SET name=?, lat=?, lng=?, description=? WHERE id=?';
  db.query(sql, [name, lat, lng, description, spotId], (err, result) => {
    if (err) {
      console.error('Errore durante l\'aggiornamento dello spot:', err);
      return res.status(500).json({ error: 'Errore durante l\'aggiornamento dello spot' });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Spot non trovato' });
    }
    res.json({ message: 'Spot aggiornato correttamente' });
  });
});

// 8) DELETE /spots/:id: Cancella uno spot
app.delete('/spots/:id', (req, res) => {
  const spotId = req.params.id;
  const sql = 'DELETE FROM spots WHERE id=?';
  db.query(sql, [spotId], (err, result) => {
    if (err) {
      console.error('Errore durante l\'eliminazione dello spot:', err);
      return res.status(500).json({ error: 'Errore durante l\'eliminazione dello spot' });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Spot non trovato o già cancellato' });
    }
    res.json({ message: 'Spot cancellato correttamente' });
  });
});

// 9) Avvio del server
app.listen(port, () => {
  console.log(`Server in ascolto su http://localhost:${port}`);
});
